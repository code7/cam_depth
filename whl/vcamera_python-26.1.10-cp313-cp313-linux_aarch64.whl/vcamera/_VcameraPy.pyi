"""Type stubs for VcameraPy module."""

from typing import Callable, Tuple, List, overload
from enum import Enum, IntEnum


class CameraInfo:
    """Complete camera information structure.

    Contains identification and status information for a camera.
    This structure is used to identify cameras and create Camera objects.

    Attributes:
        interface_info (InterfaceInfo): Interface connection details
        network_info (NetworkInfo): Network configuration (if applicable)
        usb_info (UsbInfo): USB connection details (if applicable)
        serial_number (str): Unique serial number of the camera
        name (str): Camera model name
        model (str): Camera model number
        vendor (str): Camera manufacturer/vendor
        firmware_version (str): Camera firmware version
        state (CameraState): Current camera state
    """
    interface_info: InterfaceInfo
    network_info: NetworkInfo
    usb_info: UsbInfo
    serial_number: str
    name: str
    model: str
    vendor: str
    firmware_version: str
    state: CameraState


class UsbInfo:
    """USB connection information.
    
    Contains USB-specific connection details for cameras connected
    via USB interface.
    
    Attributes:
        bus (int): USB bus number where camera is connected
        address (int): USB device address on the bus
    """
    bus: int
    address: int


class NetworkInfo:
    """Network connection information.

    Contains network configuration details for cameras connected
    via Ethernet interface.

    Attributes:
        mac (str): MAC address of the camera
        ip (str): IP address of the camera
        netmask (str): Network subnet mask
        gateway (str): Network gateway address
        broadcast (str): Network broadcast address
    """
    mac: str
    ip: str
    netmask: str
    gateway: str
    broadcast: str


class InterfaceInfo:
    """Camera interface information.

    Combines interface type with specific connection details.
    Contains all information needed to identify and connect to
    a camera through its physical interface.

    Attributes:
        interface_type (InterfaceType): Type of interface (USB/Network)
        name (str): Name of the interface
        id (str): Unique identifier for the interface
        network_info (NetworkInfo): Network-specific information
    """
    interface_type: InterfaceType
    name: str
    id: str
    network_info: NetworkInfo


class CameraApiStatusCode(IntEnum):
    """
    Camera API status code enumeration.
    
    This enumeration defines all possible API call status codes,
    used to indicate operation success or specific error types.
    """
    
    Success = ...  # Operation completed successfully
    Failure = ...  # General failure
    ArrayInfoInvalid = ...  # Array information invalid
    ArrayInvalid = ...  # Array invalid
    CalibrationInfoInvalid = ...  # Calibration information invalid
    CameraInvalid = ...  # Camera object invalid
    ComponentInvalid = ...  # Component invalid
    DeviceInvalid = ...  # Device invalid
    DeviceError = ...  # Device error
    DeviceIdle = ...  # Device idle
    DeviceBusy = ...  # Device busy
    DeviceLost = ...  # Device connection lost
    DeviceInterfaceInvalid = ...  # Device interface invalid
    DeviceInterfaceTypeError = ...  # Device interface type error
    DeviceInfoInvalid = ...  # Device information invalid
    FeatureInvalid = ...  # Feature invalid
    FeatureInfoInvalid = ...  # Feature information invalid
    FeatureTypeError = ...  # Feature type error
    FrameInvalid = ...  # Frame data invalid
    FrameMetadataInvalid = ...  # Frame metadata invalid
    FrameBufferInvalid = ...  # Frame buffer invalid
    FrameBufferConsumerInvalid = ...  # Frame buffer consumer invalid
    FrameSetInvalid = ...  # Frame set invalid
    FrameSetStreamInvalid = ...  # Frame set stream invalid
    FrameSetConsumerInvalid = ...  # Frame set consumer invalid
    TriggerModeError = ...  # Trigger mode error
    NotExist = ...  # Target does not exist
    NotImplemented = ...  # Function not implemented
    NotPermitted = ...  # Operation not permitted
    NotSupported = ...  # Operation not supported
    OutOfMemory = ...  # Out of memory
    OutOfIndexRange = ...  # Index out of range
    OutOfValueRange = ...  # Value out of allowed range
    ParameterInvalid = ...  # Parameter invalid
    StructureInfoInvalid = ...  # Structure information invalid
    StructureInvalid = ...  # Structure invalid
    Timeout = ...  # Operation timeout
    ValueInvalid = ...  # Value invalid
    ValueTypeError = ...  # Value type error
    ValueInfoInvalid = ...  # Value information invalid
    NullCameraHandle = ...  # Camera handle is null
    UserSetIsFull = ...  # User set is full
    IpcChannelNotInited = ...  # IPC channel not initialized
    CameraNotConnected = ...  # Camera not connected
    
    def __str__(self) -> str:
        """Return string representation of status code."""
        ...
    
    def __repr__(self) -> str:
        """Return detailed string representation of status code."""
        ...


class CameraApiStatus:
    """
    Camera API status class.
    
    Represents the result of an API call, containing status code and optional description.
    Used to check if an operation was successful and to get error details.
    """
    
    def __init__(self, code: CameraApiStatusCode = ..., message: str = "") -> None:
        """
        Create a CameraApiStatus object.
        
        Args:
            code: Status code (defaults to Success if not provided)
            message: Optional description, defaults to empty string
        
        Example:
            >>> status = CameraApiStatus()
            >>> print(status.IsSuccess())
            True
            >>> status = CameraApiStatus(CameraApiStatusCode.Timeout, "Operation timed out")
            >>> print(status.code())
            CameraApiStatusCode.Timeout
        """
        ...
    
    def IsSuccess(self) -> bool:
        """
        Check if operation was successful.
        
        Returns:
            True if status code is Success, False otherwise
        
        Example:
            >>> status = some_api_function()
            >>> if status.IsSuccess():
            ...     print("Operation successful")
            ... else:
            ...     print(f"Operation failed: {status.message()}")
        """
        ...
    
    def code(self) -> CameraApiStatusCode:
        """
        Get status code.
        
        Returns:
            Enumeration status code
        
        Example:
            >>> status = some_api_function()
            >>> error_code = status.code()
            >>> if error_code == CameraApiStatusCode.DeviceBusy:
            ...     print("Device busy, please try again later")
        """
        ...
    
    def message(self) -> str:
        """
        Get status description.
        
        Returns:
            Status description string
        
        Example:
            >>> status = some_api_function()
            >>> if not status.IsSuccess():
            ...     print(f"Error message: {status.message()}")
        """
        ...
    
    def __bool__(self) -> bool:
        """
        Boolean conversion operator.
        
        Allows CameraApiStatus objects to be used directly in conditional statements.
        Returns True if operation was successful, False otherwise.
        
        Example:
            >>> status = some_api_function()
            >>> if status:  # Equivalent to if status.IsSuccess():
            ...     print("Operation successful")
            ... else:
            ...     print("Operation failed")
        """
        ...
    
    def __str__(self) -> str:
        """
        Return string representation of object.
        
        Returns a JSON-style string containing code and message fields.
        
        Returns:
            JSON-formatted status string
        
        Example:
            >>> status = CameraApiStatus(CameraApiStatusCode.DeviceBusy, "Device is busy")
            >>> print(str(status))
            {"code":"CameraApiStatusCode.DeviceBusy","message":"Device is busy"}
        """
        ...
    
    def __repr__(self) -> str:
        """
        Return detailed string representation of object.
        
        Same as __str__ method, returns JSON-formatted string.
        """
        ...


class CameraState(Enum):
    """
    Camera state enumeration.
    
    Defines the current operational state of a camera.
    These states indicate connection status and capture activity.
    """
    
    NotFound = ...   # Camera device not found
    Occupied = ...   # Camera is occupied by another process
    Opened = ...     # Camera is opened/connected
    Closed = ...     # Camera is closed/disconnected
    Capturing = ...  # Camera is actively capturing frames
    Offlined = ...   # Camera is offline
    Error = ...      # Camera is in an error state


class InterfaceType(Enum):
    """
    Camera interface type enumeration.
    
    Defines the physical connection type of the camera.
    """
    
    Unknown = ...  # Unknown or unsupported interface type
    USB = ...      # USB interface
    Network = ...  # Network/Ethernet interface


class Feature:
    """Camera feature/parameter class.

    Represents a configurable parameter or feature of a camera.
    Features include settings such as exposure time, gain, frame rate,
    trigger mode, and other camera-specific controls.

    Note:
        Feature objects are typically obtained from Camera.GetFeature()
        or Camera.GetAllFeatures() and should not be constructed directly.
    """

    def __init__(self) -> None: ...
    def copy(self) -> Feature: ...
    def IsValid(self) -> bool: ...
    def GetName(self) -> str: ...
    def GetType(self) -> FeatureType: ...
    def GetAccessMode(self) -> Tuple[AccessMode, CameraApiStatus]: ...
    def GetValue(self) -> Tuple[Value, CameraApiStatus]: ...
    def SetValue(self, value) -> CameraApiStatus: ...
    def GetIntRange(self) -> Tuple[Int64Range, CameraApiStatus]: ...
    def GetFloatRange(self) -> Tuple[Float64Range, CameraApiStatus]: ...
    def GetEnumItems(self) -> Tuple[List[EnumItem], CameraApiStatus]: ...


class ImageMode:
    """Image mode specification.

    Defines the resolution and pixel format for camera image capture.
    Used to configure sensor output settings.

    Attributes:
        width (int): Image width in pixels
        height (int): Image height in pixels
        pixel_format (RawPixelFormat): Native pixel format
    """
    width: int
    height: int
    pixel_format: RawPixelFormat


class RawPixelFormat(Enum):
    """
    Raw pixel format enumeration.
    
    Defines the native pixel formats supported by the camera hardware.
    These are low-level formats directly from the sensor before processing.
    Includes Bayer patterns, monochrome, depth, RGB, YUV, and 3D coordinate formats.
    """
    
    Undefined = ...               # Undefined or unknown format
    Mono = ...                    # 8-bit monochrome (grayscale)
    Bayer8GB = ...                # 8-bit Bayer GB pattern
    Bayer8BG = ...                # 8-bit Bayer BG pattern
    Bayer8GR = ...                # 8-bit Bayer GR pattern
    Bayer8RG = ...                # 8-bit Bayer RG pattern
    Bayer8GRBG = ...              # 8-bit Bayer GR/BG pattern
    Bayer8RGGB = ...              # 8-bit Bayer RG/GB pattern
    Bayer8GBRG = ...              # 8-bit Bayer GB/RG pattern
    Bayer8BGGR = ...              # 8-bit Bayer BG/GR pattern
    CSIMono10 = ...               # 10-bit monochrome (CSI packed)
    CSIBayer10GRBG = ...          # 10-bit Bayer GR/BG (CSI packed)
    CSIBayer10RGGB = ...          # 10-bit Bayer RG/GB (CSI packed)
    CSIBayer10GBRG = ...          # 10-bit Bayer GB/RG (CSI packed)
    CSIBayer10BGGR = ...          # 10-bit Bayer BG/GR (CSI packed)
    CSIMono12 = ...               # 12-bit monochrome (CSI packed)
    CSIBayer12GRBG = ...          # 12-bit Bayer GR/BG (CSI packed)
    CSIBayer12RGGB = ...          # 12-bit Bayer RG/GB (CSI packed)
    CSIBayer12GBRG = ...          # 12-bit Bayer GB/RG (CSI packed)
    CSIBayer12BGGR = ...          # 12-bit Bayer BG/GR (CSI packed)
    Depth16 = ...                 # 16-bit depth data
    YVYU = ...                    # YVYU 4:2:2 color format
    YUYV = ...                    # YUYV 4:2:2 color format
    Mono16 = ...                  # 16-bit monochrome
    TOFIRMono16 = ...             # 16-bit TOF IR monochrome
    RGB = ...                     # 24-bit RGB (8-8-8)
    BGR = ...                     # 24-bit BGR (8-8-8)
    JPEG = ...                    # JPEG compressed image
    MJPG = ...                    # Motion JPEG compressed video
    RGB48 = ...                   # 48-bit RGB (16-16-16)
    BGR48 = ...                   # 48-bit BGR (16-16-16)
    XYZ48 = ...                   # 48-bit XYZ coordinate data
    IMU = ...                     # IMU sensor data
    Mono8 = ...                   # 8-bit monochrome (GenICam)
    BayerGB8 = ...                # 8-bit Bayer GB (GenICam)
    BayerBG8 = ...                # 8-bit Bayer BG (GenICam)
    BayerGR8 = ...                # 8-bit Bayer GR (GenICam)
    BayerRG8 = ...                # 8-bit Bayer RG (GenICam)
    Mono10p = ...                 # 10-bit monochrome packed
    CSIMono10P = ...              # 10-bit monochrome packed (CSI)
    BayerGB10p = ...              # 10-bit Bayer GB packed
    CSIBayerGB10P = ...           # 10-bit Bayer GB packed (CSI)
    BayerBG10p = ...              # 10-bit Bayer BG packed
    CSIBayerBG10P = ...           # 10-bit Bayer BG packed (CSI)
    BayerGR10p = ...              # 10-bit Bayer GR packed
    CSIBayerGR10P = ...           # 10-bit Bayer GR packed (CSI)
    BayerRG10p = ...              # 10-bit Bayer RG packed
    CSIBayerRG10P = ...           # 10-bit Bayer RG packed (CSI)
    Mono12p = ...                 # 12-bit monochrome packed
    CSIMono12P = ...              # 12-bit monochrome packed (CSI)
    BayerGB12p = ...              # 12-bit Bayer GB packed
    CSIBayerGB12P = ...           # 12-bit Bayer GB packed (CSI)
    BayerBG12p = ...              # 12-bit Bayer BG packed
    CSIBayerBG12P = ...           # 12-bit Bayer BG packed (CSI)
    BayerGR12p = ...              # 12-bit Bayer GR packed
    CSIBayerGR12P = ...           # 12-bit Bayer GR packed (CSI)
    BayerRG12p = ...              # 12-bit Bayer RG packed
    CSIBayerRG12P = ...           # 12-bit Bayer RG packed (CSI)
    CSIMono14P = ...              # 14-bit monochrome packed (CSI)
    CSIBayerGB14P = ...           # 14-bit Bayer GB packed (CSI)
    CSIBayerBG14P = ...           # 14-bit Bayer BG packed (CSI)
    CSIBayerGR14P = ...           # 14-bit Bayer GR packed (CSI)
    CSIBayerRG14P = ...           # 14-bit Bayer RG packed (CSI)
    BayerGB16 = ...               # 16-bit Bayer GB
    BayerBG16 = ...               # 16-bit Bayer BG
    BayerGR16 = ...               # 16-bit Bayer GR
    BayerRG16 = ...               # 16-bit Bayer RG
    RGB8 = ...                    # 24-bit RGB (GenICam)
    BGR8 = ...                    # 24-bit BGR (GenICam)
    YUV422_8 = ...                # YUV 4:2:2 8-bit
    YUV422_8_UYVY = ...           # UYVY 4:2:2 format
    YCbCr420_8_YY_CbCr_Planar = ...     # YCbCr 4:2:0 planar YY-Cb-Cr
    YCbCr420_8_YY_CrCb_Planar = ...     # YCbCr 4:2:0 planar YY-Cr-Cb
    YCbCr420_8_YY_CbCr_Semiplanar = ... # YCbCr 4:2:0 semiplanar YY-CbCr
    YCbCr420_8_YY_CrCb_Semiplanar = ... # YCbCr 4:2:0 semiplanar YY-CrCb
    Coord3D_C16 = ...             # 3D coordinates 16-bit
    Coord3D_ABC16 = ...           # 3D coordinates ABC 16-bit
    Coord3D_ABC32f = ...          # 3D coordinates ABC 32-bit float
    TofIR_FourGroup_Mono16 = ...  # TOF IR 4-phase 16-bit monochrome


class PixelFormat(Enum):
    """
    Simplified pixel format enumeration.
    
    High-level pixel formats used by image processing and display.
    These formats are easier to work with than the raw formats
    and are commonly used in applications.
    """
    
    Undefined = ...   # Undefined or unknown pixel format
    Depth16 = ...     # 16-bit depth data (uint16)
    Depth32F = ...    # 32-bit floating point depth data (float)
    PointCloud = ...  # 3D point cloud data (float32 x, y, z coordinates)
    Gray8 = ...       # 8-bit grayscale/monochrome (uint8)
    Gray16 = ...      # 16-bit grayscale/monochrome (uint16)
    Gray32F = ...     # 32-bit floating point grayscale (float32)
    Bgr24 = ...       # 24-bit color in BGR format (uint8, uint8, uint8)
    Rgb24 = ...       # Deprecated because the naming is confusing, use Bgr24 instead


class Image:
    """Image data container.

    Represents a single image frame captured from a camera sensor.
    Contains image data and metadata such as timestamp, calibration,
    and sensor identification.
    """

    def IsValid(self) -> bool:
        """Check whether the image contains valid data."""
        ...

    def width(self) -> int:
        """Get image width in pixels."""
        ...

    def height(self) -> int:
        """Get image height in pixels."""
        ...

    def pixel_format(self) -> PixelFormat:
        """Get pixel format of the image data."""
        ...

    def data(self):
        """Get pointer-like raw image data object from the SDK."""
        ...

    def time_stamp(self) -> int:
        """Get capture timestamp in nanoseconds."""
        ...

    def frame_index(self) -> int:
        """Get frame index (currently reserved by SDK)."""
        ...

    def sensor(self) -> str:
        """Get sensor name that produced this image."""
        ...

    def calib_info(self) -> CalibInfo:
        """Get calibration information associated with this image."""
        ...

    def scale_unit(self) -> float:
        """Get depth scale factor for depth images."""
        ...

    def to_numpy(self):
        """Convert image data to a NumPy array with format-dependent shape/dtype."""
        ...


class FrameSet:
    """Frame set container.

    Represents a synchronized set of images captured from multiple
    sensors at the same moment. Frame sets are delivered to callbacks
    registered with ``Camera.RegisterFrameSetCallback()``.

    Use ``GetImage()`` to retrieve images from specific sensors.
    """

    def GetImage(self, sensor_name: str) -> Image:
        """
        Get image from a specific sensor.

        Retrieves the image captured by the specified sensor from this
        frame set. All images in a frame set are time-synchronized.

        Args:
            sensor_name: Name of the sensor (use SensorType constants)

        Returns:
            Image from the specified sensor, or an empty image if not available.
        """
        ...


class CameraEventCode(Enum):
    """
    Camera event code enumeration.
    
    Defines event types reported by the camera, delivered to callbacks
    registered with ``Camera.RegisterCameraEventCallback()``.
    """
    
    Closed = ...   # Camera connection closed
    Opened = ...   # Camera connection opened
    Started = ...  # Camera capture started
    Stopped = ...  # Camera capture stopped
    Offlined = ... # Camera went offline
    Error = ...    # Camera error occurred


class AccessMode(Enum):
    """
    Feature access mode enumeration.
    
    Defines read/write permissions for camera features.
    Used to determine if a feature can be read, written, or both.
    """
    
    NotAvailable = ...  # Feature is not available
    Readable = ...      # Feature can only be read
    Writable = ...      # Feature can only be written
    ReadWritable = ...  # Feature can be both read and written


class FeatureType(Enum):
    """
    Camera feature type enumeration.
    
    Defines the data type of camera features/parameters.
    Used when accessing camera configuration settings.
    """
    
    Undefined = ...    # Undefined feature type
    Bool = ...         # Boolean feature (True/False)
    Int64 = ...        # 64-bit integer feature
    Float64 = ...      # 64-bit floating point feature
    Enumeration = ...  # Enumerated feature (selection from list)
    String = ...       # String feature
    ByteArray = ...    # Byte array feature (binary data)
    Dictionary = ...   # Dictionary feature (key-value pairs)


class ValueType(Enum):
    """
    Value type enumeration.
    
    Defines the fundamental data types used in the SDK.
    More granular than FeatureType for internal data representation.
    """
    
    Undefined = ...  # Undefined value type
    Bool = ...       # Boolean value
    Int8 = ...       # 8-bit signed integer
    UInt8 = ...      # 8-bit unsigned integer
    Int16 = ...      # 16-bit signed integer
    UInt16 = ...     # 16-bit unsigned integer
    Int32 = ...      # 32-bit signed integer
    UInt32 = ...     # 32-bit unsigned integer
    Int64 = ...      # 64-bit signed integer
    UInt64 = ...     # 64-bit unsigned integer
    Float32 = ...    # 32-bit floating point
    Float64 = ...    # 64-bit floating point
    String = ...     # String value
    Array = ...      # Array of values
    Dictionary = ... # Dictionary of key-value pairs


class Value:
    """Type-safe container for storing and manipulating multiple data types.

    Value can hold booleans, integer widths, floating-point values, and
    strings, with explicit runtime type information and conversion helpers.
    """

    @overload
    def __init__(self, value: bool) -> None: ...
    @overload
    def __init__(self, value: int) -> None: ...
    @overload
    def __init__(self, value: float) -> None: ...
    @overload
    def __init__(self, val: str) -> None: ...
    @overload
    def __init__(self, values: List['Value']) -> None: ...
    @overload
    def __init__(self, value, type: ValueType) -> None: ...
    def __init__(self, value=..., type: ValueType = ...) -> None: ...
    def copy(self) -> Value: ...

    def GetType(self) -> ValueType: ...
    def IsUndefined(self) -> bool: ...
    def IsBool(self) -> bool: ...
    def IsInt8(self) -> bool: ...
    def IsUInt8(self) -> bool: ...
    def IsInt16(self) -> bool: ...
    def IsUInt16(self) -> bool: ...
    def IsInt32(self) -> bool: ...
    def IsUInt32(self) -> bool: ...
    def IsInt64(self) -> bool: ...
    def IsUInt64(self) -> bool: ...
    def IsFloat(self) -> bool: ...
    def IsDouble(self) -> bool: ...
    def IsString(self) -> bool: ...
    def IsArray(self) -> bool: ...
    def IsDictionary(self) -> bool: ...
    def GetArray(self) -> List['Value']: ...

    def as_bool(self) -> bool: ...
    def as_number(self) -> int: ...
    def as_float(self) -> float: ...
    def as_string(self) -> str: ...

    def __bool__(self) -> bool: ...
    def __int__(self) -> int: ...
    def __uint__(self) -> int: ...
    def __float__(self) -> float: ...
    def __str__(self) -> str: ...
    def __repr__(self) -> str: ...


class Int64Range:
    """Integer value range.

    Defines the valid range for 64-bit integer features.
    Used to specify minimum, maximum, and step size for
    integer camera parameters.

    Attributes:
        minValue (int): Minimum allowed value
        maxValue (int): Maximum allowed value
        step (int): Step size between valid values
    """
    minValue: int
    maxValue: int
    step: int


class Float64Range:
    """Floating point value range.

    Defines the valid range for 64-bit floating point features.
    Used to specify minimum, maximum, and step size for
    floating-point camera parameters.

    Attributes:
        minValue (float): Minimum allowed value
        maxValue (float): Maximum allowed value
        step (float): Step size between valid values
    """
    minValue: float
    maxValue: float
    step: float


class CameraIntrinsic:
    """Camera intrinsic parameters.

    Represents the intrinsic camera calibration matrix (3x3) and
    image dimensions. The matrix defines focal length and principal point.

    Format:
        [fx  0  cx]
        [0  fy  cy]
        [0   0   1]

    Attributes:
        width (int): Image width in pixels
        height (int): Image height in pixels
    """
    width: int
    height: int

    @property
    def matrix(self):
        """Get or set the intrinsic matrix as a 3x3 NumPy array."""
        ...

    @matrix.setter
    def matrix(self, value) -> None:
        ...

    def copy(self) -> CameraIntrinsic:
        """Create a copy of this intrinsic parameter object."""
        ...

    def __getitem__(self, idx: Tuple[int, int]) -> float:
        """Get one matrix element using (row, column) indices."""
        ...

    def __setitem__(self, idx: Tuple[int, int], value: float) -> None:
        """Set one matrix element using (row, column) indices."""
        ...


class CameraExtrinsic:
    """Camera extrinsic parameters.

    Represents the camera's pose in world coordinates as a 4x4
    homogeneous transformation matrix.

    Format:
        [R  T]
        [0  1]

    Where:
        R: 3x3 rotation matrix
        T: 3x1 translation vector

    This matrix transforms points from world coordinates to camera coordinates.
    """

    @property
    def matrix(self):
        """Get or set the extrinsic matrix as a 4x4 NumPy array."""
        ...

    @matrix.setter
    def matrix(self, value) -> None:
        ...

    def copy(self) -> CameraExtrinsic:
        """Create a copy of this extrinsic parameter object."""
        ...

    def __getitem__(self, idx: Tuple[int, int]) -> float:
        """Get one matrix element using (row, column) indices."""
        ...

    def __setitem__(self, idx: Tuple[int, int], value: float) -> None:
        """Set one matrix element using (row, column) indices."""
        ...


class CameraDistortion:
    """Camera lens distortion coefficients.

    Contains coefficients for correcting lens distortion in images.
    Typically includes radial and tangential distortion parameters.

    Common distortion models:
        - Brown-Conrady model: [k1, k2, p1, p2, k3, ...]
        - Kannala-Brandt model: [k1, k2, k3, k4, ...]

    The exact interpretation depends on the camera calibration model.
    """

    @property
    def coefficients(self):
        """Get or set distortion coefficients as a 1D NumPy array of 12 floats."""
        ...

    @coefficients.setter
    def coefficients(self, value) -> None:
        ...

    def copy(self) -> CameraDistortion:
        """Create a copy of this distortion object."""
        ...

    def __getitem__(self, idx: int) -> float:
        """Get a single distortion coefficient by index (0-11)."""
        ...

    def __setitem__(self, idx: int, value: float) -> None:
        """Set a single distortion coefficient by index (0-11)."""
        ...


class CameraRotation:
    """Camera rotation matrix.

    A 3x3 rotation matrix representing camera orientation.
    This can be part of camera calibration or used for coordinate
    transformations between different sensors on the same camera.

    The matrix is orthonormal (R^T * R = I, det(R) = 1).
    """

    @property
    def matrix(self):
        """Get or set the rotation matrix as a 3x3 NumPy array."""
        ...

    @matrix.setter
    def matrix(self, value) -> None:
        ...

    def copy(self) -> CameraRotation:
        """Create a copy of this rotation object."""
        ...

    def __getitem__(self, idx: Tuple[int, int]) -> float:
        """Get one matrix element using (row, column) indices."""
        ...

    def __setitem__(self, idx: Tuple[int, int], value: float) -> None:
        """Set one matrix element using (row, column) indices."""
        ...


class CalibInfo:
    """Complete camera calibration information.

    Combines intrinsic, extrinsic, and distortion parameters into
    a single structure representing full camera calibration.

    Attributes:
        intrinsic (CameraIntrinsic): Intrinsic camera parameters
        extrinsic (CameraExtrinsic): Extrinsic camera pose
        distortion (CameraDistortion): Lens distortion coefficients
    """

    intrinsic: CameraIntrinsic
    extrinsic: CameraExtrinsic
    distortion: CameraDistortion

    def copy(self) -> CalibInfo:
        """Create a copy of this calibration info object."""
        ...


class PointXYZ:
    """3D point structure.

    Represents a point in 3D space with X, Y, Z coordinates.
    Used for point cloud processing and 3D transformations.

    Attributes:
        x (float): X-coordinate
        y (float): Y-coordinate
        z (float): Z-coordinate
    """

    x: float
    y: float
    z: float

    def __init__(self, x: float = 0.0, y: float = 0.0, z: float = 0.0) -> None: ...


class PointCloud:
    """3D point cloud container.

    Represents a collection of 3D points in space.
    Used for storing and manipulating 3D data obtained from depth cameras.
    """

    def __init__(self, other: PointCloud = ...) -> None: ...
    def get_points(self) -> List[PointXYZ]: ...
    def has_positions(self) -> bool: ...
    def get_point_count(self) -> int: ...


class ImageProc:
    """Image processing utilities.

    Provides static methods for processing images, including:
    - Depth filtering and enhancement
    - 2D/3D coordinate transformations
    - Image undistortion
    - Point cloud generation and manipulation
    """

    @staticmethod
    def SetParallelEnabled(enabled: bool) -> CameraApiStatus:
        """Enable or disable parallel processing for the image processing functions in this class."""
        ...
    @staticmethod
    @overload
    def UndistortImage(srcImage: Image) -> Tuple[Image, CameraApiStatus]: ...
    @staticmethod
    @overload
    def UndistortImage(srcImage: Image, newIntrinsic: CameraIntrinsic) -> Tuple[Image, CameraApiStatus]: ...
    @staticmethod
    def SpeckleFilter(imageIn: Image, difference: float, maxSpeckleSize: float) -> Tuple[Image, CameraApiStatus]: ...
    @staticmethod
    def DepthEnhenceFilter(depthImages: List[Image], sigma_s: float, sigma_r: float, outlier_win_sz: int, outlier_rate: float, guideImage: Image = ...) -> Tuple[Image, CameraApiStatus]: ...
    @staticmethod
    def DepthImageToPointCloud(depth: Image) -> Tuple[PointCloud, CameraApiStatus]: ...
    @staticmethod
    def PointCloudToDepthImage(cloud: PointCloud, depthIntrinsic: CameraIntrinsic, depthW: int, depthH: int, f_target_scale: float = 1.0) -> Tuple[Image, CameraApiStatus]: ...
    @staticmethod
    def TransformPointCloud(point3dFrom: PointCloud, extrinsic: CameraExtrinsic, inverse: bool = False) -> Tuple[PointCloud, CameraApiStatus]: ...
    @staticmethod
    def MapTextureImageToDepth(rgbIn: Image, depth: Image) -> Tuple[Image, CameraApiStatus]: ...
    @staticmethod
    def MapGrayImageToDepth(grayIn: Image, depth: Image) -> Tuple[Image, CameraApiStatus]: ...
    @staticmethod
    def MapDepthImageToTexture(depthIn: Image, rgb: Image) -> Tuple[Image, CameraApiStatus]: ...
    @staticmethod
    def DepthInpaint(inputDepth: Image, kernelSize: int, maxInternalHoleToBeFilled: int) -> Tuple[Image, CameraApiStatus]: ...
    

class EnumItem:
    """Enumeration item for feature options.

    Represents a single option in an enumerated camera feature.
    Used for features like TriggerMode, PixelFormat, etc. where the
    value is selected from a predefined list of options.

    Attributes:
        name (str): Human-readable name of the option
        value (int): Integer value used to select this option
    """

    name: str
    value: int

    def __init__(self, name: str = ..., value: int = ...) -> None: ...
    def copy(self) -> EnumItem: ...


class UserSet:
    """Camera user set/profile structure.

    Represents a saved camera configuration profile. User sets allow
    saving and loading complete camera configurations for different
    use cases.

    Attributes:
        sid (str): Unique system identifier for the user set
        name (str): Human-readable name of the user set
    """
    sid: str
    name: str


class UserSetManager:
    """Manager for camera user sets and configurations.

    The UserSetManager provides methods to save, load, and manage camera
    configuration profiles (user sets). User sets allow storing complete
    camera configurations for different scenarios and quickly switching
    between them without manually adjusting individual settings.

    Note:
        UserSetManager instances are obtained through Camera.GetUserSetManager()
        and cannot be created directly.
    """

    def GetAllUserSets(self) -> Tuple[List[UserSet], CameraApiStatus]:
        """Retrieve all available user sets from the camera."""
        ...

    def SaveToUserSet(self, user_set) -> CameraApiStatus:
        """Save current camera settings to an existing user set."""
        ...

    def SaveToUserSetWithNewName(self, old_name: str, new_name: str) -> CameraApiStatus:
        """Save current settings to a user set with a new name."""
        ...

    def CurrentUserSet(self) -> Tuple[str, CameraApiStatus]:
        """Get the name of the currently active user set."""
        ...

    def LoadUserSet(self, name: str) -> CameraApiStatus:
        """Load an existing user set to configure the camera."""
        ...

    def GetPowerOnUserSet(self) -> Tuple[str, CameraApiStatus]:
        """Retrieve the name of the user set that loads at power-on."""
        ...

    def SetPowerOnUserSet(self, name: str) -> CameraApiStatus:
        """Set an existing user set to load automatically at power-on."""
        ...


class Camera:
    """
    Main camera control class.
    
    The Camera class provides a high-level interface for controlling camera devices.
    It supports camera connection/disconnection, capture control, feature management,
    sensor configuration, and callback registration for frame and event handling.
    """
    
    def GetCameraInfo(self) -> Tuple[CameraInfo, CameraApiStatus]:
        """
        Retrieve camera information.
        
        Gets detailed information about the camera device including model,
        serial number, firmware version, and other device-specific details.
        
        Returns:
            tuple: (CameraInfo, CameraApiStatus) where CameraInfo contains
                   camera details and CameraApiStatus indicates success/failure
        
        Example:
            >>> camera = CameraFactory.GetCameraBySerialNumber("12345")
            >>> info, status = camera.GetCameraInfo()
        """
        ...
    
    def Connect(self, session_key: str = "") -> CameraApiStatus:
        """
        Connect to the camera device.
        
        Establishes a connection to the camera device. The camera must be
        connected before performing any operations.
        
        Args:
            session_key: Optional session key for camera access,
                        used for secure access control. Defaults to empty string.
                        Most users can ignore this parameter unless RPC mode is used.
        
        Returns:
            CameraApiStatus: Status indicating success or failure of the connection
        
        Example:
            >>> camera = CameraFactory.GetCameraBySerialNumber("12345")
            >>> status = camera.Connect()
        """
        ...
    
    def Disconnect(self) -> CameraApiStatus:
        """
        Disconnect from the camera device.
        
        Closes the connection to the camera and releases associated resources.
        This should be called when the camera is no longer needed.
        
        Returns:
            CameraApiStatus: Status indicating success or failure of disconnection
        Example:
            >>> camera = ...  # already connected camera
            >>> camera.StopCapture()  # stop capture first
            >>> status = camera.Disconnect()
        """
        ...
    
    def GetCameraState(self) -> Tuple[CameraState, CameraApiStatus]:
        """
        Get the current camera state.
        
        Retrieves the current operational state of the camera including
        connection status, capture state, and other runtime information.
        
        Returns:
            tuple: (CameraState, CameraApiStatus) where CameraState contains
                   current camera status and CameraApiStatus indicates success/failure
        
        Example:
            >>> state, status = camera.GetCameraState()
        """
        ...
    
    def StartCapture(self) -> CameraApiStatus:
        """
        Start image capture.
        
        Begins capturing images from the camera.
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> status = camera.StartCapture()
        """
        ...
    
    def StopCapture(self) -> CameraApiStatus:
        """
        Stop image capture.
        
        Stops capturing images from the camera.
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> status = camera.StopCapture()
        """
        ...
    
    def GetFeature(self, feature_name: str) -> Tuple[Feature, CameraApiStatus]:
        """
        Retrieve a camera feature by name.
        
        Gets a specific feature from the camera.
        
        Args:
            feature_name: Name of the feature to retrieve
        
        Returns:
            tuple: (Feature, CameraApiStatus) where CameraApiStatus indicates success/failure
        
        Example:
            >>> # Get the exposure time feature
            >>> feature, status = camera.GetFeature("DepthScaleUnit")
        """
        ...
    
    def GetAllFeatures(self) -> Tuple[List[Feature], CameraApiStatus]:
        """
        Retrieve all camera features.
        
        Gets all available features from the camera.
        
        Returns:
            tuple: (list[Feature], CameraApiStatus) where the list contains
                   all available features and CameraApiStatus indicates success/failure
        
        Example:
            >>> features, status = camera.GetAllFeatures()
        """
        ...
    
    def FireSoftwareTrigger(self) -> CameraApiStatus:
        """
        Fire a software trigger.
        
        Send a software trigger to the camera.
        This is useful only when the camera is in software trigger mode.
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> status = camera.FireSoftwareTrigger()
        """
        ...
    
    def GetImageModes(self, sensor_id: str) -> Tuple[List[ImageMode], CameraApiStatus]:
        """
        Get available image modes for a specific sensor.
        
        Retrieves all supported image resolution and format modes for the
        specified sensor.
        
        Args:
            sensor_id: Name of the sensor, such as SensorType.Depth
        
        Returns:
            tuple: (list[ImageMode], CameraApiStatus) where the list contains
                   available image modes and CameraApiStatus indicates success/failure
        
        Example:
            >>> modes, status = camera.GetImageModes(SensorType.Depth)
        """
        ...
    
    def GetCurrentImageMode(self, sensor_id: str) -> Tuple[ImageMode, CameraApiStatus]:
        """
        Get the current image mode for a specific sensor.
        
        Retrieves the currently active image resolution and format for the
        specified sensor.
        
        Args:
            sensor_id: Name of the sensor, such as SensorType.Depth
        
        Returns:
            tuple: (ImageMode, CameraApiStatus) where ImageMode contains
                   current image settings and CameraApiStatus indicates success/failure
        
        Example:
            >>> mode, status = camera.GetCurrentImageMode(SensorType.DEPTH)
        """
        ...
    
    def SetImageMode(self, sensor_id: str, mode: ImageMode) -> CameraApiStatus:
        """
        Set the image mode for a specific sensor.
        
        Configures the image resolution and format for the specified sensor.
        The camera must not be capturing when changing image modes.
        
        Args:
            sensor_id: Name of the sensor, such as SensorType.Depth
            mode: Image mode to set
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> modes, status = camera.GetImageModes(SensorType.Depth)
            >>> status = camera.SetImageMode(SensorType.DEPTH, modes[0])
        """
        ...
    
    def HasSensor(self, sensor_name: str) -> Tuple[bool, CameraApiStatus]:
        """
        Check if a specific sensor exists on the camera.
        
        Determines whether the camera has the specified sensor type.
        
        Args:
            sensor_name: Name of the sensor to check
        
        Returns:
            tuple: (bool, CameraApiStatus) where bool indicates if sensor exists
                   and CameraApiStatus indicates success/failure
        
        Example:
            >>> has_depth, status = camera.HasSensor(SensorType.Texture)
        """
        ...
    
    def IsSensorEnabled(self, sensor_name: str) -> Tuple[bool, CameraApiStatus]:
        """
        Check if a specific sensor is enabled.
        
        Determines whether the specified sensor is currently enabled and
        producing data.
        
        Args:
            sensor_name: Name of the sensor to check
        
        Returns:
            tuple: (bool, CameraApiStatus) where bool indicates if sensor is enabled
                   and CameraApiStatus indicates success/failure
        
        Example:
            >>> enabled, status = camera.IsSensorEnabled(SensorType.Depth)
        """
        ...
    
    def SetSensorEnabled(self, sensor_name: str, enable: bool) -> CameraApiStatus:
        """
        Enable or disable a specific sensor.
        
        Controls whether a sensor is active and producing data.
        Disabling unused sensors can improve performance and reduce power consumption.
        
        Args:
            sensor_name: Name of the sensor to configure
            enable: True to enable the sensor, False to disable
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> status = camera.SetSensorEnabled(SensorType.Depth, False)
        """
        ...
    
    def SetUndistortionEnabled(self, sensor_id: str, enable: bool) -> CameraApiStatus:
        """
        Enable or disable undistortion for a specific sensor.
        
        Controls whether lens distortion correction is applied to images
        from the specified sensor. Undistortion corrects for optical
        distortions in the camera lens.
        
        Args:
            sensor_id: Name of the sensor
            enable: True to enable undistortion, False to disable
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> status = camera.SetUndistortionEnabled(SensorType.Texture, True)
        """
        ...
    
    def IsMapDepthToTextureEnabled(self) -> Tuple[bool, CameraApiStatus]:
        """
        Check if depth-to-texture mapping is enabled.
        
        Determines whether depth image is mapped to the texture image.
        
        Returns:
            tuple: (bool, CameraApiStatus) where bool indicates if mapping is enabled
                   and CameraApiStatus indicates success/failure
        
        Example:
            >>> enabled, status = camera.IsMapDepthToTextureEnabled()
        """
        ...
    
    def IsMapDepthToColorEnabled(self) -> Tuple[bool, CameraApiStatus]:
        """
        Check if depth-to-texture mapping is enabled.
        
        .. deprecated::
            Use IsMapDepthToTextureEnabled instead.
        """
        ...
    
    def SetMapDepthToTextureEnabled(self, enable: bool) -> CameraApiStatus:
        """
        Enable or disable depth-to-texture mapping.
        
        When enabled, depth image is aligned to the texture image.
        
        Args:
            enable: True to enable mapping, False to disable
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> status = camera.SetMapDepthToTextureEnabled(True)
        """
        ...
    
    def SetMapDepthToColorEnabled(self, enable: bool) -> CameraApiStatus:
        """
        Enable or disable depth-to-texture mapping.
        
        .. deprecated::
            Use SetMapDepthToTextureEnabled instead.
        """
        ...

    def IsMapTextureToDepthEnabled(self) -> Tuple[bool, CameraApiStatus]:
        """
        Check if texture-to-depth mapping is enabled.
        
        Determines whether texture image is mapped to the depth image.
        
        Returns:
            tuple: (bool, CameraApiStatus) where bool indicates if mapping is enabled
                   and CameraApiStatus indicates success/failure
        
        Example:
            >>> enabled, status = camera.IsMapTextureToDepthEnabled()
        """
        ...

    def SetMapTextureToDepthEnabled(self, enable: bool) -> CameraApiStatus:
        """
        Enable or disable texture-to-depth mapping.
        
        When enabled, texture image is aligned to the depth image.
        
        Args:
            enable: True to enable mapping, False to disable
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> status = camera.SetMapTextureToDepthEnabled(True)
        """
        ...

    def GetFactoryCalibInfo(self, sensor_name: str) -> Tuple[CalibInfo, CameraApiStatus]:
        """
        Retrieve the original factory calibration information for a specific sensor.

        The returned CalibInfo contains original, immutable calibration data that
        remains constant for the lifetime of the device. It includes:

        - intrinsic: the intrinsic corresponding to the sensor's native resolution
          - Left/Right: the intrinsics before stereo rectification
        - extrinsic: a transformation matrix whose meaning depends on the sensor:
          - Depth:   identity matrix
          - Texture: Texture-to-Depth transform
          - Left:    identity matrix. For stereo cameras, Depth and Left both have identity extrinsic matrices,
                     meaning they share the same coordinate, which is the world coordinate.
          - Right:   Left-to-Right transform, before stereo rectification
        - distortion: lens distortion coefficients
          - Left/Right: the distortion before stereo rectification

        Args:
            sensor_name: Name of the sensor to query

        Returns:
            tuple: (CalibInfo, CameraApiStatus)
        """
        ...

    def GetRectificationRotation(self, sensor_name: str) -> Tuple[CameraRotation, CameraApiStatus]:
        """
        Retrieve the rectification rotation for a specific sensor.

        Returns the rotation matrix applied to stereo rectification.
        Only valid for stereo sensors: Left and Right.

        Args:
            sensor_name: Name of the sensor to query

        Returns:
            tuple: (CameraRotation, CameraApiStatus)
        """
        ...

    def GetRectifiedIntrinsic(self, sensor_name: str) -> Tuple[CameraIntrinsic, CameraApiStatus]:
        """
        Retrieve the intrinsic parameters after stereo rectification for a specific sensor.

        Returns the intrinsic matrix computed after stereo rectification.

        Args:
            sensor_name: Name of the sensor to query

        Returns:
            tuple: (CameraIntrinsic, CameraApiStatus)
        """
        ...

    def GetRectifiedExtrinsic(self, sensor_name: str) -> Tuple[CameraExtrinsic, CameraApiStatus]:
        """
        Retrieve the extrinsic parameters after stereo rectification for a specific sensor.

        Returns the Left-to-Right extrinsic matrix computed after stereo rectification.
        Only valid for the Right sensor.

        Args:
            sensor_name: Name of the sensor to query (SensorType.Right only)

        Returns:
            tuple: (CameraExtrinsic, CameraApiStatus)
        """
        ...

    def SaveFeaturesToFile(self, file_path: str) -> CameraApiStatus:
        """
        Save camera features to a file.
        
        Args:
            file_path: Path to the file where features will be saved.
                      It's recommended to use paths with ASCII characters only.
                      The parent folder of the file must exist before calling this function.
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> status = camera.SaveFeaturesToFile("camera_config.json")
        """
        ...
    
    def LoadFeaturesFromFile(
        self,
        file_path: str,
        restore_sensor_enable_state: bool = True,
        restore_acquisition_and_trigger: bool = True,
    ) -> Tuple[CameraApiStatus, str]:
        """
        Load camera features from a file.
        
        Imports camera settings (features) from a JSON file previously
        created with SaveFeaturesToFile.
        
        Args:
            file_path: Path to the file from which features will be loaded.
                      It's recommended to use paths with ASCII characters only.
                      The file must exist before calling this function.
            restore_sensor_enable_state: Whether to restore sensor enabled/disabled state from file.
            restore_acquisition_and_trigger: Whether to restore acquisition and trigger-related settings.
        
        Returns:
            tuple: (CameraApiStatus, str) where CameraApiStatus indicates
                   success/failure and str contains error details if failed
        
        Example:
            >>> status, error_msg = camera.LoadFeaturesFromFile("camera_config.json")
        """
        ...
    
    def SaveFeaturesToStorage(self) -> CameraApiStatus:
        """Save modified camera features to storage."""
        ...
    
    def LoadFeaturesFromStorage(
        self,
        restore_sensor_enable_state: bool = True,
        restore_acquisition_and_trigger: bool = True,
    ) -> Tuple[CameraApiStatus, str]:
        """Load camera features from storage.

        Args:
            restore_sensor_enable_state: Whether to restore sensor enabled/disabled state from storage.
            restore_acquisition_and_trigger: Whether to restore acquisition and trigger-related settings.
        """
        ...
    
    def GetUserSetManager(self) -> UserSetManager:
        """
        Get the user set manager for camera configuration management.
        
        Returns the UserSetManager instance which provides methods to
        manage camera user sets.
        
        Returns:
            UserSetManager: Manager for camera user sets
        
        Example:
            >>> uset_manager = camera.GetUserSetManager()
        """
        ...
    
    def RegisterFrameSetCallback(self, callback: Callable[[FrameSet], None]) -> None:
        """
        Register a callback for frame set events.
        
        Registers a function to be called when new frame sets are available
        from the camera.
        
        Args:
            callback: Function to be called with FrameSet parameter.
                     The function signature should be:
                     def callback(frame_set: FrameSet) -> None
        
        Example:
            >>> def process_frames(frame_set):
            ...     # Get depth frame
            ...     depth_frame = frame_set.GetImage(SensorType.Depth)
            ...     if depth_frame.IsValid():
            ...         # Process depth data...
            ...     
            >>> 
            >>> camera.RegisterFrameSetCallback(process_frames)
            >>> camera.StartCapture()  # Callback will now receive frames
        """
        ...
    
    def RegisterCameraEventCallback(self, callback: Callable[[CameraEventCode, int], None]) -> None:
        """
        Register a callback for camera events.
        
        Registers a function to be called when camera events occur, such as
        disconnection, error conditions, or other status changes.
        
        Args:
            callback: Function to be called with event parameters.
                     The function signature should be:
                     def callback(event_code: CameraEventCode, param: int) -> None
        
        Example:
            >>> def handle_camera_events(event_code, param):
            ...     if event_code == CameraEventCode.Offlined:
            ...         print(f"Camera offline")
            ...         # Handle disconnection...
            ...     elif event_code == CameraEventCode.Error:
            ...         print(f"Camera error: {param}")
            >>> 
            >>> camera.RegisterCameraEventCallback(handle_camera_events)
            >>> # Callback will now receive camera events
        """
        ...


class CameraFactory:
    """
    Factory class for creating Camera instances.

    The CameraFactory provides static methods to create Camera objects using
    different identification methods such as serial number, IP address, or
    camera information structure.
    """

    @staticmethod
    def GetCameraBySerialNumber(serial_number: str) -> Camera:
        """
        Create a Camera instance using serial number.

        Args:
            serial_number: The serial number of the camera to connect to

        Returns:
            Camera object configured for the specified device

        Example:
            >>> # Create camera using serial number
            >>> camera = CameraFactory.GetCameraBySerialNumber("207000000001")
        """
        ...

    @staticmethod
    def GetCameraByIpAddress(ip_address: str) -> Camera:
        """
        Create a Camera instance using IP address.

        Args:
            ip_address: The IP address of the camera to connect to

        Returns:
            Camera object configured for the specified device

        Example:
            >>> # Create camera using IP address (for network cameras)
            >>> camera = CameraFactory.GetCameraByIpAddress("192.168.1.100")
        """
        ...

    @staticmethod
    def GetCameraByCameraInfo(camera_info: CameraInfo) -> Camera:
        """
        Create a Camera instance using camera information.

        Args:
            camera_info: CameraInfo structure containing camera details

        Returns:
            Camera object configured for the specified device

        Example:
            >>> # First get list of available cameras
            >>> cameras = CameraUtils.DiscoverCameras()
            >>>
            >>> if len(cameras) == 0:
            >>>     print('No cameras found!')
            >>>     return
            >>> # Select a camera from the list
            >>> camera_info = cameras[0]
            >>> # Create camera using the camera info
            >>> camera = CameraFactory.GetCameraByCameraInfo(camera_info)
        """
        ...


class LogDestination(Enum):
    """
    Logging destination enumeration.
    
    Defines where log messages should be output to.
    Multiple destinations can be enabled simultaneously.
    """
    
    Console = ...  # Output logs to console/stdout
    File = ...     # Write logs to a file
    Server = ...   # Send logs to a remote logging server


class ServerType(Enum):
    """
    Server protocol type enumeration.
    
    Defines the network protocol used for remote logging or streaming.
    """
    
    Udp = ...  # UDP protocol - connectionless, faster but unreliable
    Tcp = ...  # TCP protocol - connection-oriented, reliable


class LogLevel(Enum):
    """
    Logging level enumeration.
    
    Defines the severity levels for SDK logging output.
    Use these levels to control the verbosity of log messages.
    """
    
    Verbose = ...  # Verbose logging - detailed debugging information
    Debug = ...    # Debug logging - general debugging information
    Info = ...     # Info logging - informational messages
    Warn = ...     # Warning logging - potential issues
    Error = ...    # Error logging - recoverable errors
    Fatal = ...    # Fatal logging - unrecoverable errors


class CameraUtils:
    """
    Camera utility functions.
    
    Provides static methods for camera discovery, initialization,
    logging configuration, and network management. These utilities
    handle system-level operations.
    """
    
    @staticmethod
    def Init(use_direct_call: bool) -> CameraApiStatus:
        """
        Initialize the camera SDK.
        
        Initializes the SDK and prepares it for camera operations.
        This must be called before any other SDK functions.
        
        Args:
            use_direct_call: Communication mode to use

                - True: Direct call mode (recommended for most users)

                - False: RPC call mode (for advanced multi-process scenarios)
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> # Initialize SDK with direct call mode (recommended)
            >>> status = CameraUtils.Init(True)
        """
        ...
    
    @staticmethod
    def DiscoverCameras() -> List[CameraInfo]:
        """
        Discover all available cameras.
        
        Scans the system (USB and network) for connected cameras
        and returns information about each found device.
        
        Returns:
            list[CameraInfo]: List of discovered camera information structures
        
        Example:
            ... cameras = CameraUtils.DiscoverCameras()
            ... print(f"Found {len(cameras)} camera(s)")
        """
        ...
    
    @staticmethod
    def EnableVcameraSdkLog(log_dest: LogDestination, enable: bool) -> CameraApiStatus:
        """
        Enable or disable Vcamera SDK logging.
        
        Args:
            log_dest: Where to send the log messages
            enable: True to enable logging, False to disable
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> # Enable console logging for Vcamera SDK
            >>> status = CameraUtils.EnableVcameraSdkLog(
            ...     LogDestination.Console, True)
        """
        ...
    
    @staticmethod
    def SetVcameraSdkLogLevel(level: LogLevel) -> CameraApiStatus:
        """
        Set the log level for Vcamera SDK.
        
        Controls the verbosity of Vcamera SDK log messages.
        Lower levels produce more detailed output.
        
        Args:
            level: Minimum severity level to log
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> status = CameraUtils.SetVcameraSdkLogLevel(
            ...     LogLevel.Warn)
        """
        ...
    
    @staticmethod
    def SetIpAddress(
        camera_info: CameraInfo,
        ip: str,
        mask: str = "",
        gateway: str = ""
    ) -> CameraApiStatus:
        """
        Set static IP address for a network camera using CameraInfo.
        
        Configures a network camera with a static IP address.
        
        Args:
            camera_info: Information of the camera to configure
            ip: New static IP address for the camera
            mask: Subnet mask
            gateway: Gateway address
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> # Discover cameras first
            >>> cameras = CameraUtils.DiscoverCameras()
            >>> if cameras:
            ...     camera_info = cameras[0]
            ...     # Set static IP for the first camera
            ...     status = CameraUtils.SetIpAddress(
            ...         camera_info, "192.168.1.100", "255.255.255.0", "192.168.1.1")
            ...     if status.IsSuccess():
            ...         print("Camera IP address set successfully")
        """
        ...
    
    @staticmethod
    def SetIpAddress(
        mac: str,
        ip: str,
        mask: str = "",
        gateway: str = ""
    ) -> CameraApiStatus:
        """
        Set static IP address for a network camera using MAC address.
        
        Configures a network camera with a static IP address using its
        MAC address as identifier. Useful when CameraInfo is not available.
        
        Args:
            mac: MAC address of the camera (format: "00:11:22:33:44:55")
            ip: New static IP address for the camera
            mask: Subnet mask
            gateway: Gateway address
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> # Set static IP using MAC address
            >>> status = CameraUtils.SetIpAddress(
            ...     "00:11:22:33:44:55", "192.168.1.101", "255.255.255.0")
            >>> if status.IsSuccess():
            ...     print("Camera IP address set successfully")
        """
        ...
    
    @staticmethod
    def SetIpToDynamic(camera_info: CameraInfo) -> CameraApiStatus:
        """
        Set camera IP address to dynamic (DHCP) using CameraInfo.
        
        Configures a network camera to obtain its IP address automatically
        via DHCP. This reverts a static IP configuration.
        
        Args:
            camera_info: Information of the camera to configure
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> # Discover cameras first
            >>> cameras = CameraUtils.DiscoverCameras()
            >>> if cameras:
            ...     camera_info = cameras[0]
            ...     # Set camera to use DHCP
            ...     status = CameraUtils.SetIpToDynamic(camera_info)
            ...     if status.IsSuccess():
            ...         print("Camera set to use DHCP successfully")
        """
        ...
    
    @staticmethod
    def SetIpToDynamic(mac: str) -> CameraApiStatus:
        """
        Set camera IP address to dynamic (DHCP) using MAC address.
        
        Configures a network camera to obtain its IP address automatically
        via DHCP using its MAC address as identifier.
        
        Args:
            mac: MAC address of the camera (format: "00:11:22:33:44:55")
        
        Returns:
            CameraApiStatus: Status indicating success or failure
        
        Example:
            >>> # Set camera to use DHCP using MAC address
            >>> status = CameraUtils.SetIpToDynamic("00:11:22:33:44:55")
            >>> if status.IsSuccess():
            ...     print("Camera set to use DHCP successfully")
        """
        ...


class SensorType:
    """
    Sensor type constants.
    
    Predefined string constants representing different types of sensors
    available on cameras. Use these constants when specifying
    which sensor to access or configure.
    """
    
    Depth: str
    """Depth sensor - captures distance/depth information."""
    
    Left: str
    """Left stereo sensor - typically for stereo vision systems."""
    
    Right: str
    """Right stereo sensor - typically for stereo vision systems."""
    
    Texture: str
    """Texture sensor - typically color/RGB sensor."""
    
    DEPTH: str
    """
    Deprecated: Use Depth instead.
    
    .. deprecated::
        Use SensorType.Depth instead.
    """
    
    LEFT: str
    """
    Deprecated: Use Left instead.
    
    .. deprecated::
        Use SensorType.Left instead.
    """
    
    RIGHT: str
    """
    Deprecated: Use Right instead.
    
    .. deprecated::
        Use SensorType.Right instead.
    """
    
    COLOR: str
    """
    Deprecated: Use Texture instead.
    
    .. deprecated::
        Use SensorType.Texture instead.
    """


def GetVersionString() -> str:
    """
    Get full version string.
    
    Returns the complete version string of the VcameraPy SDK,
    including major, minor, and patch version numbers.
    
    Returns:
        str: Full version string (e.g., "26.1.1_0.3.4-57c5d5d_4.2.10")
    
    Example:
        >>> import vcamera as vcam
        >>> version = vcam.GetVersionString()
        >>> print(f"SDK Version: {version}")
    """
    ...
